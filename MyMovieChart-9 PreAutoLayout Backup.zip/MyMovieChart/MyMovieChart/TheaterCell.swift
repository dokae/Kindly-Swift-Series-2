//
//  TheaterCell.swift
//  MyMovieChart
//
//  Created by Park Jae Han on 26/07/2019.
//  Copyright © 2019 Park Jae Han. All rights reserved.
//

import UIKit

class TheaterCell: UITableViewCell {
    
    
    @IBOutlet var name: UILabel!
    @IBOutlet var addr: UILabel!
    @IBOutlet var tel: UILabel!
    
}
