//
//  ListViewController.swift
//  MyMovieChart
//
//  Created by Park Jae Han on 23/07/2019.
//  Copyright © 2019 Park Jae Han. All rights reserved.
//

import UIKit

class ListViewController: UITableViewController {
    
    // 프로퍼티 초기화 & 테이블뷰를 구성할 리스트데이터
    lazy var list: [MovieVO] = {        // lazy로 마지막에 초기화
        var datalist = [MovieVO]()
        return datalist
    }()
    
    override func viewDidLoad() {
        
        // 1.API호출위한 URI생성
        let url = "http://swiftapi.rubypaper.co.kr:2029/hoppin/movies?version=1&page=1&count=10&genreId=&order=releasedateasc"
        let apiURI: URL! = URL(string: url)
        
        // 2.REST API호출
        let apidata = try! Data(contentsOf: apiURI)
        
        // 3.데이터 전송 결과를 log출력(선택사항)
        let log = NSString(data: apidata, encoding: String.Encoding.utf8.rawValue) ?? "" // A ?? B, 만약 A가 nil이 아니라면 옵셔널 해제, nil이라면 B사용
        NSLog("API Result=\( log )")
        
        // 4.JSON객체를 파싱하여 NSDictionary객체로 받음
        do {
            let apiDictionary = try JSONSerialization.jsonObject(with: apidata, options: []) as! NSDictionary
            
            // 5. 데이터구조에 따라 차례대로 캐스팅하며 읽어옴
            let hoppin = apiDictionary["hoppin"] as! NSDictionary
            let movies = hoppin["movies"] as! NSDictionary
            let movie = movies["movie"] as! NSArray
            
            //6. Iterator(순회)처리를 하며 API데이터를 MovieVO객체에 저장
            for row in movie {
                let r = row as! NSDictionary
                
                let mvo = MovieVO()
                mvo.title = r["title"] as? String
                mvo.description = r["genreNames"] as? String
                mvo.thumbnail = r["thumbnailImage"] as? String
                mvo.detail = r["linkUrl"] as? String
                mvo.rating = (r["ratingAverage"] as! NSString).doubleValue
                
                self.list.append(mvo)
            }
        }
        catch {}
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.list.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
        let row = self.list[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "ListCell") as! MovieCell
        
        cell.title?.text = row.title
        cell.desc?.text = row.description
        cell.opendate?.text = row.opendate
        cell.rating?.text = "\(row.rating!)"
        
        let url: URL! = URL(string: row.thumbnail!)
        let imageData = try! Data(contentsOf: url)
        cell.thumbnail.image = UIImage(data: imageData)

        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("selected row is \(indexPath.row)")
    }
    
    
}
